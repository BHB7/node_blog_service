const { getArticleServiceById,
    createArticleService,
    delArticleService,
    updateArticleService,
    getArticlePageService
} = require('../service/articleService');
// 创建文章
const createArticleController = async (req, res) => {
    // 从 JWT 中获取用户 ID
    const user_id = req.auth?.id || req.user?.id; // 兼容 req.auth 和 req.user
    const ip = req.user.ip;
    const system = req.user.system;

    console.log(user_id);

    if (!user_id) {
        return res.error('用户未登录或 Token 无效', 401);
    }

    const { title, content, desc, cover, tagIds = [], state='010' } = req.body;
    // 必填字段
    const requiredFields = { title, content, user_id };

    // 遍历必填字段进行校验
    for (const [key, value] of Object.entries(requiredFields)) {
        if (!value) {
            return res.error(`${key}: 小参数不合法呢，可能是太害羞了~`);
        }
    }

    // 合并所有字段
    const articleData = { ...requiredFields, desc, cover, tagIds, ip, system, state };

    try {
        // 调用创建文章服务
        const article = await createArticleService(articleData);
        res.success(article, '文章创建成功');
    } catch (err) {
        // 错误日志打印，方便调试
        console.error('创建文章失败:', err);
        res.error(err.message || '创建文章失败', 500);
    }
};

// 更新文章
const updateArticleController = async (req, res) => {
    if (!req.body) {
        return res.error('请求体为空，请确认请求格式是否为 JSON');
    }

    const { aid, title, content, desc, cover, user_id, state, tagIds, subset_id } = req.body;

    // 校验文章 ID 和必填字段
    if (!aid) {
        return res.error('文章ID (aid) 不能为空');
    }

    try {
        // 调用更新文章服务
        const isOk = await updateArticleService(aid, { title, content, desc, cover, user_id, state, tagIds, subset_id });
        if (isOk) {
            res.success(null, '更新成功');
        } else {
            res.error('更新失败，找不到文章');
        }
    } catch (err) {
        console.error('更新文章失败:', err);
        res.error('更新失败', err.message);
    }
};

// 通过aid获取文章详情
const getArticleControllerById = async (req, res) => {
    try {
        const { aid } = req.params;
        if (!aid) return res.error('请传入aid');
        const response = await getArticleServiceById(aid);
        res.success(response);
    } catch (error) {
        res.error('获取文章详情失败啦');
    };
};

// 获取文章分页的控制器
const getArticlePageController = async (req, res) => {
    try {
        // 合并 req.body 和 req.query，确保参数来源统一
        const reqData = { ...req.query, ...req.body };

        // 提取分页参数并转换为数字，并设置默认值
        let { pageSize = 10, pageOffset = 0 } = reqData;
        const { state, title, content, tagIds } = reqData;
        pageSize = Number(pageSize) || 10;
        pageOffset = Number(pageOffset) || 0;
        // 调用服务层查询文章，并返回 total 与 list 对象（假设服务返回结构已优化）
        const pageList = await getArticlePageService({ query: {state, title, content, tagIds} ,pageSize, pageOffset });

        // 成功响应
        res.success(pageList);
    } catch (error) {
        console.error('获取文章分页失败:', error);
        res.error('获取文章分页失败');
    }
};

// 通过id删除文章
const delArticleController = async (req, res) => {
    const { aid } = req.params;
    try {
       const flag = await delArticleService(aid);
       if(!flag) throw new Error("删除失败了");
       res.success(flag, '删除成功');
    } catch (error) {
        res.error(error.message || '呜呜~服务器出了点问题');
    }
}
module.exports = {
    createArticleController,
    updateArticleController,
    getArticlePageController,
    getArticleControllerById,
    delArticleController
};
